﻿using ClassLibrary.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary.Services
{
    public interface IAppServices
    {
        public void AddPost(Post p);

        public Post GetPost(int id);

        public void RemovePost(int id);

        public void UpdatePost(Post p);

        public void AddComment(Comment p);

        public ObservableCollection<Post> GetAllPost();
    }
}
