﻿using ClassLibrary.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary.Services
{
    public class AppServices : IAppServices
    {
        Context c;
        public AppServices() { 
            
            c = new Context();
        }

        public void AddComment(Comment p)
        {
            c.Comments.Add(p);
        }

        public void AddPost(Post p)
        {
            c.Posts.Add(p);
        }

        public ObservableCollection<Post> GetAllPost()
        {
            return new ObservableCollection<Post>(c.Posts);
        }

        public Post GetPost(int id)
        {
            return (from p in c.Posts where p.Id == id select p).FirstOrDefault<Post>();
        }

        public void RemovePost(int id)
        {
            foreach (Post item in c.Posts){
                if (item.Id == id) { 
                
                    c.Posts.Remove(item);
                }
            }
        }

        public void UpdatePost(Post p)
        {
            c.Posts.Update(p);
            c.SaveChanges();
        }
    }
}
